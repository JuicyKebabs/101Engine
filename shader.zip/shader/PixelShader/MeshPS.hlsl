#include "../BasicShader.hlsli"
#include "../FrameConstants.hlsli"
#include "../MeshObjectConstants.hlsli"
#include "../LightConstants.hlsli"

Texture2D gTexture : register(t0); // Texture object
Texture2D gShadowMap : register(t1); // Shadow map texture object
SamplerState gSampler : register(s0); // Texture sampler state
SamplerComparisonState gShadowSampler : register(s1); // Shadow map sampler state

float CalculateShadow(float4 worldPos)
{
    float4 lightSpacePos = mul(lightViewProj, worldPos); // Convert world position to light space
    lightSpacePos.xyz /= lightSpacePos.w; // Perspective divide
    
    // Convert to [0,1] range for texture sampling
    float2 shadowUV;
    shadowUV.x = lightSpacePos.x * 0.5f + 0.5f;
    shadowUV.y = -lightSpacePos.y * 0.5f + 0.5f;
    
    // Check if the position is outside the shadow map bounds
    if(shadowUV.x < 0.0f || shadowUV.x > 1.0f || shadowUV.y < 0.0f || shadowUV.y > 1.0f)
    {
        return 1.0f; // Outside of shadow map, consider fully lit
    }
    
    float currentDepth = lightSpacePos.z; // Depth of the current pixel in light space
    
    // Hardware PCF sampling using SampleCmpLevelZero
    float shadow = gShadowMap.SampleCmpLevelZero(
    gShadowSampler,
    shadowUV,
    currentDepth
    );

    return shadow; // Returns a value between 0.0 (fully in shadow) and 1.0 (fully lit)
}

float4 main(VSOutPut input) : SV_TARGET
{
    float4 base = gTexture.Sample(gSampler, input.uv) * input.color;
    
#ifdef USE_MASK
     clip(base.a - 0.1f);
#endif
    
#ifdef MULTIPLY_ALPHA_CONTROL
    base.rgb *= base.a;
#endif

#ifdef USE_LIGHTING
    float3 normal = normalize(input.normal);
    float3 length = normalize(-lightDir_Intensity.xyz);
    float dotValue = saturate(dot(normal, length));
    
    float intensity = lightDir_Intensity.w;
    float3 color = lightColor_Ambient.rgb;
    float ambient = lightColor_Ambient.a;
    
    float4 worldPos = float4(input.worldPos, 1.0f);
    float shadow = CalculateShadow(worldPos);
    
    float3 lit = color * (ambient + dotValue * intensity * shadow);
    base = float4(base.rgb * lit, base.a);
#endif
    
    return base;
}

