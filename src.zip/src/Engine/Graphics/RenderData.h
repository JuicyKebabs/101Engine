#pragma once
#include <DirectXMath.h>
#include "Engine/Component/AssimpNodeTransformAnim.h"
#include "Engine/Core/Utility/SharedStruct.h"
#include "Engine/Core/Math/Math.h"
#include <vector>

// Forward declarations
class Renderer;
class TextureManager;
class MeshManager;
class MeshGPU;
struct NodeAnimationAsset;

//=======================================================================================================
// Pipeline State Object (PSO) key structure,
// and related enumerations for shader management and rendering configurations
//=======================================================================================================

//-------------------------------------------------------------------------------------
// File IDs for shaders (used to identify which shader file to use)
//-------------------------------------------------------------------------------------
// Enumeration for vertex shader IDs
enum class VS_FILE_ID
{
	Mesh = 0,
	Sprite = 1,
	PostEffect = 2,
};
// Enumeration for pixel shader IDs
enum class PS_FILE_ID
{
	Mesh = 0,
	Sprite = 1,
	PostEffect = 2,
};

//-------------------------------------------------------------------------------------
// Entry point IDs for shaders (used to identify which entry point in the shader file to use)
//-------------------------------------------------------------------------------------
// Enumeration for vertex shader entry points
enum class VS_ENTRY_ID : uint16_t
{
	Main = 0,
};
// Enumeration for pixel shader entry points
enum class PS_ENTRY_ID : uint16_t
{
	Main = 0,
};

//-------------------------------------------------------------------------------------
// Defines for shaders (used to specify shader variants based on compile-time options)
//-------------------------------------------------------------------------------------
// Vertex shader defines (using bit flags)
enum class VS_DEFINE : uint64_t
{
	None = 0,
	Test = 1ull << 1,
};
// Pixel shader defines (using bit flags)
enum class PS_DEFINE : uint64_t
{
	None = 0,
	UseMask = 1ull << 1,
	MultiplyAlphaControll = 1ull << 2,
	UseLighting = 1ull << 3,
};
// Common shader defines (using bit flags)
enum class COMMON_SHADER_DEFINE : uint64_t
{
	None = 0,
	Test = 1ull << 1,
};

//-------------------------------------------------------------------------------------
// Shader key structure for caching compiled shaders, 
// combining file ID, entry point, and defines
//-------------------------------------------------------------------------------------
struct VS_KEY
{
	VS_FILE_ID fileID = VS_FILE_ID::Mesh;		//Vertex shader file ID
	VS_ENTRY_ID entryID = VS_ENTRY_ID::Main;	//Vertex shader entry point
	uint64_t defines = 0;						//Vertex shader defines

	bool operator == (const VS_KEY& other) const
	{
		return 
			fileID == other.fileID &&
			entryID == other.entryID &&
			defines == other.defines;
	}
};
struct PS_KEY
{
	PS_FILE_ID fileID = PS_FILE_ID::Mesh;		//Pixel shader file ID
	PS_ENTRY_ID entryID = PS_ENTRY_ID::Main;	//Pixel shader entry point
	uint64_t defines = 0;						//Pixel shader defines

	bool operator == (const PS_KEY& other) const
	{
		return 
			fileID == other.fileID &&
			entryID == other.entryID &&
			defines == other.defines;
	}
};

//-------------------------------------------------------------------------------------
// Enumerations for rendering states (blend modes, depth stencil modes, culling modes)
//-------------------------------------------------------------------------------------
// Blend modes
enum class BlendMode
{
	Opaque,
	Alpha,
	AddAlpha,
	Add,
	Multiply,
};
// Depth stencil modes
enum class DepthMode
{
	Disable,
	TestWrite,
	TestNoWrite,
};
// Culling modes
enum class CullMode
{
	None,
	Front,
	Back,
};

// Render target formats
enum class RenderTargetFormat
{
	LDR,
	HDR,
};

// Pipeline State Object (PSO) key structure
struct PSOKey
{
	VS_KEY vsKey;											// Vertex shader key
	PS_KEY psKey;											// Pixel shader key
	uint64_t commonDefines = 0;								// Common shader defines
	BlendMode  blend = BlendMode::Opaque;					// Blend mode
	DepthMode  depth = DepthMode::Disable;					// Depth stencil mode
	CullMode  cull = CullMode::None;						// Culling mode
	RenderTargetFormat rtvFormat = RenderTargetFormat::LDR;	// Render target format
	bool indexFree = false;									// Whether to use index-free drawing (e.g., for sprites)

	// Equality operators for PSOKey
	bool operator == (const PSOKey& other) const
	{
		return 
			vsKey == other.vsKey &&
			psKey == other.psKey &&
			commonDefines == other.commonDefines &&
			blend == other.blend &&
			depth == other.depth &&
			cull == other.cull &&
			rtvFormat == other.rtvFormat &&
			indexFree == other.indexFree;
	}
	bool operator != (const PSOKey& other) const
	{
		return !(*this == other);
	}

	// Helper functions to create modified PSOKeys with additional defines
	PSOKey WithLighting() const {
		PSOKey k = *this;
		k.psKey.defines |= static_cast<uint64_t>(PS_DEFINE::UseLighting);
		return k;
	}

	// Add multiple vertex shader defines at once
	PSOKey AddVSDefines(std::initializer_list<VS_DEFINE> defines) const {
		PSOKey k = *this;
		for (auto d : defines) {
			k.vsKey.defines |= static_cast<uint64_t>(d);
		}
		return k;
	}
	// Add multiple pixel shader defines at once
	PSOKey AddPSDefines(std::initializer_list<PS_DEFINE> defines) const {
		PSOKey k = *this;
		for (auto d : defines) {
			k.psKey.defines |= static_cast<uint64_t>(d);
		}
		return k;
	}
	// Add multiple common shader defines at once
	PSOKey AddCommonDefines(std::initializer_list<COMMON_SHADER_DEFINE> defines) const {
		PSOKey k = *this;
		for (auto d : defines) {
			k.commonDefines |= static_cast<uint64_t>(d);
		}
		return k;
	}

	// Get combined defines for vertex shader (common + specific)
	uint64_t GetCombinedDefinesVS() const {
		return vsKey.defines | commonDefines;
	}
	// Get combined defines for pixel shader (common + specific)
	uint64_t GetCombinedDefinesPS() const {
		return psKey.defines | commonDefines;
	}
};

namespace PSO_KEY_DEFAULT
{
	// Predefined PSO keys for common rendering configurations
	inline constexpr PSOKey MESH_OPAQUE{ VS_KEY{.fileID = VS_FILE_ID::Mesh}, PS_KEY{.fileID = PS_FILE_ID::Mesh}, 0, BlendMode::Opaque, DepthMode::TestWrite, CullMode::None, RenderTargetFormat::LDR };
	inline constexpr PSOKey MESH_TRANSPARENT{ VS_KEY{.fileID = VS_FILE_ID::Mesh}, PS_KEY{.fileID = PS_FILE_ID::Mesh}, 0, BlendMode::Alpha, DepthMode::TestNoWrite, CullMode::None, RenderTargetFormat::LDR };
	inline constexpr PSOKey MESH_MASKED{ VS_KEY{.fileID = VS_FILE_ID::Mesh}, PS_KEY{.fileID = PS_FILE_ID::Mesh, .defines = static_cast<uint64_t>(PS_DEFINE::UseMask)}, 0, BlendMode::Opaque, DepthMode::TestWrite, CullMode::None, RenderTargetFormat::LDR };
	inline constexpr PSOKey MESH_ADDITIVE{ VS_KEY{.fileID = VS_FILE_ID::Mesh}, PS_KEY{.fileID = PS_FILE_ID::Mesh}, 0, BlendMode::AddAlpha, DepthMode::TestNoWrite, CullMode::None, RenderTargetFormat::LDR };
	inline constexpr PSOKey MESH_MULTIPLY{ VS_KEY{.fileID = VS_FILE_ID::Mesh}, PS_KEY{.fileID = PS_FILE_ID::Mesh,.defines = static_cast<uint64_t>(PS_DEFINE::MultiplyAlphaControll)}, 0, BlendMode::Multiply, DepthMode::TestNoWrite, CullMode::None, RenderTargetFormat::LDR };

	inline constexpr PSOKey SPRITE_OPAQUE{ VS_KEY{.fileID = VS_FILE_ID::Sprite}, PS_KEY{.fileID = PS_FILE_ID::Sprite}, 0, BlendMode::Opaque, DepthMode::TestWrite, CullMode::None, RenderTargetFormat::LDR, true };
	inline constexpr PSOKey SPRITE_TRANSPARENT{ VS_KEY{.fileID = VS_FILE_ID::Sprite}, PS_KEY{.fileID = PS_FILE_ID::Sprite}, 0, BlendMode::Alpha, DepthMode::TestNoWrite, CullMode::None, RenderTargetFormat::LDR, true };
	inline constexpr PSOKey SPRITE_MASKED{ VS_KEY{.fileID = VS_FILE_ID::Sprite}, PS_KEY{.fileID = PS_FILE_ID::Sprite,.defines = static_cast<uint64_t>(PS_DEFINE::UseMask)}, 0, BlendMode::Opaque, DepthMode::TestWrite, CullMode::None, RenderTargetFormat::LDR, true };
	inline constexpr PSOKey SPRITE_ADDITIVE{ VS_KEY{.fileID = VS_FILE_ID::Sprite}, PS_KEY{.fileID = PS_FILE_ID::Sprite}, 0, BlendMode::AddAlpha, DepthMode::TestNoWrite, CullMode::None, RenderTargetFormat::LDR, true };
	inline constexpr PSOKey SPRITE_MULTIPLY{ VS_KEY{.fileID = VS_FILE_ID::Sprite}, PS_KEY{.fileID = PS_FILE_ID::Sprite,.defines = static_cast<uint64_t>(PS_DEFINE::MultiplyAlphaControll)}, 0, BlendMode::Multiply, DepthMode::TestNoWrite, CullMode::None, RenderTargetFormat::LDR, true };
}

// Hash function for PSOKey to be used in unordered_map
struct PSOKeyHash
{
	size_t operator()(const PSOKey& k) const noexcept
	{
		size_t h1 = std::hash<VS_FILE_ID>{}(k.vsKey.fileID) ^ std::hash<PS_FILE_ID>{}(k.psKey.fileID);
		size_t h2 = std::hash<VS_ENTRY_ID>{}(k.vsKey.entryID) ^ std::hash<PS_ENTRY_ID>{}(k.psKey.entryID);
		size_t h3 = std::hash<int>{}(static_cast<int>(k.blend)) ^ std::hash<int>{}(static_cast<int>(k.depth)) ^ std::hash<int>{}(static_cast<int>(k.cull)) ^ std::hash<int>{}(static_cast<int>(k.rtvFormat));
		size_t h4 = std::hash<bool>{}(k.indexFree);
		size_t h5 = std::hash<uint64_t>{}(k.commonDefines) ^ std::hash<uint64_t>{}(k.vsKey.defines) ^ std::hash<uint64_t>{}(k.psKey.defines);
		return (((h1 ^ (h2 << 1)) ^ (h3 << 2)) ^ (h4 << 3)) ^ (h5 << 4);
	}
};

// Render queue enumeration
enum class RenderQueue
{
	Invalied = -1,
	Opaque = 0,
	Additive = 1,
	Transparent = 2,
};

// Helper function to determine render queue based on blend mode
static inline RenderQueue GetRenderQueueFromBlendMode(BlendMode blendMode)
{
	return (blendMode == BlendMode::Opaque) ? RenderQueue::Opaque : RenderQueue::Transparent;
}

//=======================================================================================================
//�`����\���̌Q
//=======================================================================================================

// Type of Billboard
enum class BillboardType
{
	None,			//�r���{�[�h�Ȃ�
	Spherical,	//�S���r���{�[�h
	FixedX,		//X���Œ�r���{�[�h
	FixedY,		//Y���Œ�r���{�[�h
	FixedZ,		//Z���Œ�r���{�[�h
};

//=======================================================================================================
//���b�V���E���f���f�[�^�\����
//=======================================================================================================
//���b�V���f�[�^�\����
struct Mesh
{
	std::vector<Vertex> vertices;		//���_�f�[�^�z��
	size_t vertexCount = 0;				//���_��
	std::vector<uint32_t> indices;		//�C���f�b�N�X�f�[�^�z��
	size_t indexCount = 0;				//�C���f�b�N�X��
	std::wstring texPath;				//�e�N�X�`���̃t�@�C����
	DirectX::XMFLOAT4 materialColor		//�ގ��F(RGBA)
	{
		1.0f,	//�g�U���ːFR
		1.0f,	//�g�U���ːFG
		1.0f,	//�g�U���ːFB
		1.0f	//�g�U���ːFA
	};
	Vector3 boundsCenter{};				//�o�E���f�B���O�X�t�B�A�̒��S���W(�\�[�g�p)
	float boundsRadius = 0.0f;			//�o�E���f�B���O�X�t�B�A�̔��a(�\�[�g�p)
	NodeAnimationAsset nodeAnimAsset{};	// �m�[�h�A�j���[�V�������Y
};

// Bone data structure
struct Bone
{
	std::wstring name;				// Bone name
	int parentIndex = -1;			// Parent bone index (-1 if root)
	DirectX::XMMATRIX offset;		// Offset matrix
	int nodeIndex = -1;				// Node index in the model's node hierarchy
};

// Skeleton data structure
struct Skeleton
{
	std::vector<Bone> bones;						// Bone array
	std::unordered_map<std::wstring, int> boneMap;	// Map from bone name to index
};

struct AnimationClip
{
	std::wstring name;	// Animation clip name
	float duration;		// Duration in seconds
	float ticksPerSecond; // Ticks per second
};

using Model = std::vector<Mesh>;	//���f���f�[�^�\����(�����̃��b�V������Ȃ郂�f��)

//mesh type enumeration
enum class DEFAULT_MESH
{
	QUAD,		//quad plane
	CUBE,		//cube
	CIRCLE,		//circle plane
	SPHERE,		//sphere
	CAPSULE,	//capsule
	CYLINDER,	//cylinder
};

//=======================
//�l�p����
//=======================
//�l�p���ʂ̒��_�f�[�^
static const Vertex QuadVertices[4] =
{
	{{-0.5f, 0.5f, 0.0f}, {0,0,1}, {0,0}, {1,0,0}, {1,1,1,1}},	//���_0
	{{ 0.5f, 0.5f, 0.0f}, {0,0,1}, {1,0}, {1,0,0}, {1,1,1,1}},	//���_1
	{{ 0.5f,-0.5f, 0.0f}, {0,0,1}, {1,1}, {1,0,0}, {1,1,1,1}},	//���_2
	{{-0.5f,-0.5f, 0.0f}, {0,0,1}, {0,1}, {1,0,0}, {1,1,1,1}},	//���_3
};

//�l�p���ʂ̃C���f�b�N�X�f�[�^
inline uint32_t QuadIndices[6] =
{
	0,1,2,	//�O�p�`1
	0,2,3	//�O�p�`2
};

//�l�p���ʂ̃��b�V���f�[�^�쐬�֐�
Model MakeQuadModel();

//=======================
//������
//=======================
//�����̂̒��_�f�[�^(24���_)
static const Vertex CubeVertices[24] =
{
	// +Z
	{{-0.5,  0.5,  0.5}, {0,0,1}, {0,0}, {1,0,0}, {1,1,1,1}},	//���_0
	{{ 0.5,  0.5,  0.5}, {0,0,1}, {1,0}, {1,0,0}, {1,1,1,1}},	//���_1
	{{ 0.5, -0.5,  0.5}, {0,0,1}, {1,1}, {1,0,0}, {1,1,1,1}},	//���_2
	{{-0.5, -0.5,  0.5}, {0,0,1}, {0,1}, {1,0,0}, {1,1,1,1}},	//���_3

	// -Z
	{{ 0.5,  0.5, -0.5}, {0,0,-1}, {0,0}, {-1,0,0}, {1,1,1,1}},	//���_4
	{{-0.5,  0.5, -0.5}, {0,0,-1}, {1,0}, {-1,0,0}, {1,1,1,1}},	//���_5
	{{-0.5, -0.5, -0.5}, {0,0,-1}, {1,1}, {-1,0,0}, {1,1,1,1}},	//���_6
	{{ 0.5, -0.5, -0.5}, {0,0,-1}, {0,1}, {-1,0,0}, {1,1,1,1}},	//���_7

	// +X
	{{ 0.5,  0.5,  0.5}, {1,0,0}, {0,0}, {0,0,-1}, {1,1,1,1}},	//���_1
	{{ 0.5,  0.5, -0.5}, {1,0,0}, {1,0}, {0,0,-1}, {1,1,1,1}},	//���_5
	{{ 0.5, -0.5, -0.5}, {1,0,0}, {1,1}, {0,0,-1}, {1,1,1,1}},	//���_6
	{{ 0.5, -0.5,  0.5}, {1,0,0}, {0,1}, {0,0,-1}, {1,1,1,1}},	//���_2

	// -X
	{{-0.5,  0.5, -0.5}, {-1,0,0}, {0,0}, {0,0,1}, {1,1,1,1}},	//���_4
	{{-0.5,  0.5,  0.5}, {-1,0,0}, {1,0}, {0,0,1}, {1,1,1,1}},	//���_0
	{{-0.5, -0.5,  0.5}, {-1,0,0}, {1,1}, {0,0,1}, {1,1,1,1}},	//���_3
	{{-0.5, -0.5, -0.5}, {-1,0,0}, {0,1}, {0,0,1}, {1,1,1,1}},	//���_7

	// +Y
	{{-0.5,  0.5, -0.5}, {0,1,0}, {0,0}, {1,0,0}, {1,1,1,1}},		//���_4
	{{ 0.5,  0.5, -0.5}, {0,1,0}, {1,0}, {1,0,0}, {1,1,1,1}},		//���_5
	{{ 0.5,  0.5,  0.5}, {0,1,0}, {1,1}, {1,0,0}, {1,1,1,1}},		//���_1
	{{-0.5,  0.5,  0.5}, {0,1,0}, {0,1}, {1,0,0}, {1,1,1,1}},		//���_0

	// -Y
	{{-0.5, -0.5,  0.5}, {0,-1,0}, {0,0}, {1,0,0}, {1,1,1,1}},	//���_3
	{{ 0.5, -0.5,  0.5}, {0,-1,0}, {1,0}, {1,0,0}, {1,1,1,1}},	//���_2
	{{ 0.5, -0.5, -0.5}, {0,-1,0}, {1,1}, {1,0,0}, {1,1,1,1}},	//���_6
	{{-0.5, -0.5, -0.5}, {0,-1,0}, {0,1}, {1,0,0}, {1,1,1,1}},	//���_7
};

//�����̂̃C���f�b�N�X�f�[�^
inline constexpr uint32_t CubeIndices[42] =
{
	// +Z
	0,1,2,  0,2,3,			//�O�p�`1�A2
	// -Z
	4,6,5,  4,7,6,			//�O�p�`3�A4
	// +X
	8,9,10,  8,10,11,		//�O�p�`5�A6
	// -X
	12,13,14,  12,14,15,	//�O�p�`7�A8
	// +Y
	16,17,18,  16,18,19,	//�O�p�`9�A10
	// -Y
	20,21,22,  20,22,23		//�O�p�`11�A12
};

//�����̂̃��b�V���f�[�^�쐬�֐�
Model MakeCubeModel();

//=======================
//�~�`����
//=======================
//�~�`���ʂ̃��b�V���f�[�^�쐬�֐�
Model MakeCircleModel(int slice = 32);

//=======================
//����
//=======================
//���̂̃��b�V���f�[�^�쐬�֐�
Model MakeSphereModel(int slice = 32, int stacks = 16);

//=======================
//�J�v�Z��
//=======================
//�J�v�Z���̃��b�V���f�[�^�쐬�֐�
Model MakeCapsuleModel(int slice = 32, int stacks = 16);

//�J�v�Z���̃r�W���A���L�q�\����
struct CapsuleVisualDesc
{
	float baseRadius = 0.5f;		//��ʔ��a
	float basehalfHeight = 0.5f;	//�����̍���
};

////�J�v�Z���̕`����ǉ��֐�
//void AppendCapsuleRenderInfos(
//	const CapsuleVisualDesc& desc,				//�J�v�Z���`����L�q�q
//	const DirectX::XMFLOAT3& position,			//�ʒu
//	const DirectX::XMFLOAT3& scale,				//�X�P�[��
//	const DirectX::XMFLOAT3& rotEuler,			//��]Euler�p
//	const DirectX::XMFLOAT4& color,				//�F
//	std::vector<WorldRenderInfo>& infos,	//���͌��`����z��
//	std::vector<WorldRenderInfo>& out	//�o�͐�`����z��
//);

//=======================
//�~��
//=======================
//�~���̃��b�V���f�[�^�쐬�֐�
Model MakeCylinderModel(int slice = 32, int stacks = 16);

//���b�V���f�[�^�擾�֐�
inline Model GetDefaultModel(DEFAULT_MESH type)
{
	//���b�V���^�C�v�ɉ��������b�V���f�[�^��Ԃ�
	switch (type)
	{
	case DEFAULT_MESH::QUAD: return MakeQuadModel();			//�l�p����
	case DEFAULT_MESH::CUBE: return MakeCubeModel();			//������
	case DEFAULT_MESH::SPHERE: return MakeSphereModel();		//����
	case DEFAULT_MESH::CIRCLE: return MakeCircleModel();		//�~�`����
	case DEFAULT_MESH::CAPSULE: return MakeCapsuleModel();	//�J�v�Z��
	case DEFAULT_MESH::CYLINDER: return MakeCylinderModel();	//�~��
	default:   return {};						//���̑�
	}
}