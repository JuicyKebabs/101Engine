#include "Actor.h"
#include "d3dx12.h"
#include <DirectXMath.h>
#include "Engine/Engine.h"
#include "Engine/Graphics/Renderer.h"
#include "Engine/Graphics/RenderData.h"
#include "Engine/Component/Transform.h"
#include "Engine/Component/Behavior.h"
#include "Engine/Scene/SceneBase.h"
#include "Engine/Core/Math/Math.h"

using namespace DirectX;


// Destructor
Actor::~Actor()
{
}

// Post-update (for late update)
void Actor::PreUpdate(float deltaTime)
{
	AddPendingComponents();

	// Post-update all components
	for (const auto& component : m_componentPtrs) {
		// If the component has not been started, call OnStart and mark it as started
		if (!component->IsStarted()) { 
			component->OnStart(); 
		}

		// Call PostUpdate for each component
		component->PreUpdate(deltaTime);
	}
}

// Update
void Actor::Update(float deltaTime)
{
	// Update all components
	for (const auto& component : m_componentPtrs) { component->Update(deltaTime); }
}

// Late update
void Actor::LateUpdate(float deltaTime)
{
	// Late update all components
	std::vector<Component*> destroyedComponents;
	for (const auto& component : m_componentPtrs) {
		if (component->IsDestroyed()) 
		{
			destroyedComponents.push_back(component);
			continue;
		}
		component->LateUpdate(deltaTime);
	}

	// Remove components marked for destruction
	for (auto& destroyed : destroyedComponents) {
		RemoveDestroyedComponents(destroyed);
	}
}

// Mark as actor as destroyed
void Actor::Destroy()
{
	m_destroyed = true;
}

// Check if actor is destroyed
bool Actor::IsDestroyed()
{
	return m_destroyed;
}

// Get child actors by recursively traversing the hierarchy
std::vector<Actor*> Actor::GetChildren() const
{
	std::vector<Actor*> result;
	for (auto& child : m_children) {
		result.push_back(child);
		auto childChildren = child->GetChildren();
		result.insert(result.end(), childChildren.begin(), childChildren.end());
	}
	return result;
}

// Update world transform of this actor and all child actors;
void Actor::FlushTransform()
{
	auto pTransform = GetComponentByClass<Transform>();
	if (pTransform) pTransform->UpdateGeometry();
}

void Actor::FlushColliderTransforms()
{
	auto colliders = GetComponentsByClass<Collider>();
	for (auto& collider : colliders) collider->Flush();
}

// Add pending components to the main component container
void Actor::AddPendingComponents()
{
	for(auto& pending : m_pendingComponents) {
		auto& instance = pending.instance;
		m_componentPtrs.push_back(instance.get());
		auto& bucket = m_components[pending.typeId];
		bucket.instances.push_back(std::move(instance));
	}

	m_pendingComponents.clear();
}

// Remove components marked for destruction
void Actor::RemoveDestroyedComponents(Component* component)
{
	component->OnDestroy();

	auto mapIt = m_components.find(std::type_index(typeid(*component)));
	if (mapIt != m_components.end()) {
		auto& instances = mapIt->second.instances;
		auto instance = std::find_if(instances.begin(), instances.end(), [component](const std::unique_ptr<Component>& instance) {
			return instance.get() == component;
			});
		if (instance != instances.end()) {
			instances.erase(instance);
		}
	}

	auto ptrIt = std::find(m_componentPtrs.begin(), m_componentPtrs.end(), component);
	if (ptrIt != m_componentPtrs.end()) {
		m_componentPtrs.erase(ptrIt);
	}
}

// Add a child actor to the scene
void Actor::AddChildActorToScene(std::unique_ptr<Actor> child)
{
	if (m_pOwner) {
		m_pOwner->AddActorToPending(std::move(child));
	}
}
