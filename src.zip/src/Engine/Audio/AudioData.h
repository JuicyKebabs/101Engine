#pragma once
#include <string>

namespace AudioData
{
	enum class AUDIO_TYPE
	{
		AUDIO_NONE = 0,
		AUDIO_BGM_TITLE,
		AUDIO_BGM_GAME_NORMAL,
		AUDIO_BGM_GAME_BOSS,
		AUDIO_BGM_RESULT_GAME_OVER,
		AUDIO_BGM_RESULT_CLEAR,
		AUDIO_SE_PRESS_BUTTON,
		AUDIO_SE_PLAYER_DAMAGE,
		AUDIO_SE_PLAYER_SHOT,
		AUDIO_SE_PLAYER_BOOST,
		AUDIO_SE_ENEMY_DAMAGE,
		AUDIO_SE_TOMOS_SHOT,
		AUDIO_SE_BOSS_SHOT,
		AUDIO_SE_BOSS_GUARD,
		AUDIO_SE_EXPLOSION,
		AUDIO_SE_EXPLOSION_MIDDLE,
		AUDIO_SE_EXPLOSION_LARGE,
	};

	enum class COMMAND_TYPE
	{
		COMMAND_NONE = 0,
		COMMAND_LOAD,
		COMMAND_PLAY,
		COMMAND_STOP,
		COMMAND_UNLOAD,
	};

	struct AudioCommand
	{
		COMMAND_TYPE command = COMMAND_TYPE::COMMAND_NONE;
		AUDIO_TYPE type = AUDIO_TYPE::AUDIO_NONE;
		bool loop = false;
	};

	struct AudioInfo
	{
		AUDIO_TYPE type = AUDIO_TYPE::AUDIO_NONE;
		std::string filePath = "";
		int id = -1;
		bool isLoaded = false;
		bool isPlaying = false;
	};
}